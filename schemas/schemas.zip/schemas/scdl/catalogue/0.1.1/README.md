---
permalink: /scdl/catalogue/0.1.1.html
redirect_from: null
title: Catalogue simplifié
version: 0.1.1
---

# Schéma relatif au catalogue des jeux de données publiés en opendata par une collectivité