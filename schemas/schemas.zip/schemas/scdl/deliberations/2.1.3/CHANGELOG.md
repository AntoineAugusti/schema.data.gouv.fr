---
permalink: /scdl/deliberations/latest/changelog.html
redirect_from: /scdl/deliberations/2.1.3/changelog.html
title: CHANGELOG de Délibérations
version: 2.1.3
---

# Changelog

## 2.1.3

Changements internes :
- utilisation des [métadonnées standardisées](https://github.com/frictionlessdata/specs/blob/master/specs/patterns.md#table-schema-metadata-properties)

## 2.1.2

Changements internes :
  - ajout de la propriété `updated`
  - ajout de la propriété `uri`
  - ajout de la propriété `examples`
  - amélioration des titres, descriptions et exemples

## 2.1.1

Changements internes :
 - abandon de la contrainte `pattern` non conforme pour le champ `DELIB_MATIERE_NOM`, le custom check `nomenclature_actes_value` suffit.