---
permalink: /scdl/plats-menus-collectifs/latest/changelog.html
redirect_from: /scdl/plats-menus-collectifs/0.7.0/changelog.html
title: CHANGELOG de Composition des plats des menus de la restauration collective
version: 0.7.0
---

# Changelog

## 0.7

* mise à jour de la syntaxe des champs de type tableau
* mise à jour de la description
* mise à jour des fichiers exemples
* ajout ds champs platEtablissementNom et platEtablissementSiret


## 0.6

* renommage des champs suite aux recommandations SCDL mises à jour
* mise à jour des fichiers exemples

## 0.5

* concaténation des champs nutriments et quantité nutriments
* ajout des champs SIQO et Label au niveau des produits
* suppression du champ nombre de convives
* mise à jour des fichiers d'exemples

## 0.4

* ajout des informations sur les nutriments (nom en quantité pour 100g)
* mise à jour des fichiers exemples
* infomrations sur les fournisseurs
* distinction entre plats / produits et ingrédients

## 0.3

* Modification des libellés des champs platProduitNutri-score et platProduitPrix

## 0.2

* Evolution en lien avec les modifications du schéma sur les menus

## 0.1

* Création à partir des exemples de fichiers publiés et de discussion avec des représentant des collectivités locales.