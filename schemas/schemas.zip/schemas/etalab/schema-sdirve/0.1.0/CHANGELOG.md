---
permalink: /etalab/schema-sdirve/latest/changelog.html
redirect_from: /etalab/schema-sdirve/0.1.0/changelog.html
title: CHANGELOG de Schéma directeur des infrastructures de recharge pour véhicules
  électriques et hybrides rechargeables
version: 0.1.0
---

# Changelog

Ce fichier répertorie les changements entre différentes versions d'un schéma.

## Version 0.1.1 - 2019-05-06

- Clarification de la description du champ `date_creation`

## Version 0.1.0 - 2018-06-29

Publication initiale.