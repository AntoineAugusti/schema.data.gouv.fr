---
permalink: /etalab/schema-vehicules-faibles-emissions-renouvellement-parc/latest/changelog.html
redirect_from: /etalab/schema-vehicules-faibles-emissions-renouvellement-parc/0.1.1/changelog.html
title: CHANGELOG de Part des véhicules à faibles émissions dans le renouvellement
  d'un parc
version: 0.1.1
---

# Changelog

Ce fichier répertorie les changements entre différentes versions d'un schéma.

## Version 0.1.0 - 2021-09-17

- Mise à jour du schéma suite à la mise à jour de l'arrêté du 29 décembre 2020 par l'arrêté du 28 avril 2021

## Version 0.1.0 - 2021-09-16

- Publication initiale