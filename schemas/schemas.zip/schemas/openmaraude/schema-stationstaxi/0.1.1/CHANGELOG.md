---
permalink: /openmaraude/schema-stationstaxi/latest/changelog.html
redirect_from: /openmaraude/schema-stationstaxi/0.1.1/changelog.html
title: CHANGELOG de Stations de taxi
version: 0.1.1
---

# Changelog

Ce fichier répertorie les changements entre différentes versions d'un schéma.

## Version 0.1.1 - 2021-09-07

- Fusion des longitude et latitude avec le nouveau type geopoint.

## Version 0.1.0 - 2021-08-24

- Première publication sur https://schema.data.gouv.fr/

## Version 0.0.4 - 2021-07-19

- Suppression des propriétés secondaires.
- Ajout de détails sur l’occupation des stations.

## Version 0.0.3 - 2021-05-03

- Intégration des échanges avec Grenoble Alpes Métropole.
- Utilisation du format CSV par défaut.

## Version 0.0.2 - 2021-04-28

- Intégration de propositions de Grenoble Alpes Métropole.

## Version 0.0.1 - 2021-04-07

- Proposition initiale.